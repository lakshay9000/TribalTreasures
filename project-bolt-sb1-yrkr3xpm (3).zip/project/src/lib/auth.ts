import { supabase } from './supabase';

interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  address?: string;
  phone?: string;
  bio?: string;
  avatar?: string;
  isSeller?: boolean;
  shopName?: string;
  shopDescription?: string;
}

class Auth {
  async signUp(email: string, password: string, name: string, isSeller: boolean = false): Promise<{ user: User | null; error: string | null }> {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error('User creation failed');
      }

      // Create profile in profiles table
      const { error: profileError } = await supabase
        .from('profiles')
        .insert([
          {
            id: authData.user.id,
            name,
            is_seller: isSeller,
          },
        ]);

      if (profileError) throw profileError;

      const user: User = {
        id: authData.user.id,
        email: authData.user.email!,
        name,
        createdAt: new Date().toISOString(),
        isSeller,
      };

      localStorage.setItem('currentUser', JSON.stringify(user));
      return { user, error: null };
    } catch (error: any) {
      console.error('SignUp error:', error);
      return { user: null, error: error.message };
    }
  }

  async signIn(email: string, password: string): Promise<{ user: User | null; error: string | null }> {
    try {
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error('Login failed');
      }

      // Get profile data
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .single();

      if (profileError) throw profileError;

      const user: User = {
        id: authData.user.id,
        email: authData.user.email!,
        name: profileData.name,
        createdAt: profileData.created_at,
        isSeller: profileData.is_seller,
        address: profileData.address,
        phone: profileData.phone,
        avatar: profileData.avatar_url,
        shopName: profileData.shop_name,
        shopDescription: profileData.shop_description,
      };

      localStorage.setItem('currentUser', JSON.stringify(user));
      return { user, error: null };
    } catch (error: any) {
      console.error('SignIn error:', error);
      return { user: null, error: error.message };
    }
  }

  async signOut(): Promise<void> {
    await supabase.auth.signOut();
    localStorage.removeItem('currentUser');
  }

  async updateProfile(userId: string, updates: Partial<Omit<User, 'id' | 'email'>>): Promise<{ user: User | null; error: string | null }> {
    try {
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          name: updates.name,
          avatar_url: updates.avatar,
          address: updates.address,
          phone: updates.phone,
          shop_name: updates.shopName,
          shop_description: updates.shopDescription,
        })
        .eq('id', userId);

      if (profileError) throw profileError;

      const currentUser = this.getCurrentUser();
      if (!currentUser) {
        throw new Error('No current user found');
      }

      const updatedUser = {
        ...currentUser,
        ...updates,
      };

      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      return { user: updatedUser, error: null };
    } catch (error: any) {
      console.error('Update profile error:', error);
      return { user: null, error: error.message };
    }
  }

  getCurrentUser(): User | null {
    const currentUser = localStorage.getItem('currentUser');
    return currentUser ? JSON.parse(currentUser) : null;
  }
}

export const auth = new Auth();